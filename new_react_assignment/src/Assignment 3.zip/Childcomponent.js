import React from 'react'

function Childcomponent(props) {
    return (
        <div>
            <button onClick={props.displayhandler}>display</button>
                    </div>
    )
}


export default Childcomponent
