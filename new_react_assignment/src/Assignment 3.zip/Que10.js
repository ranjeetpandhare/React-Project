// We will create a parent component named “Home”, two components
// named “Login” and “Logout” and one more component named
// “DispalyMessage”. We will use a state variable named “isLoggedIn” to
// store the information about whether the user is logged in or not. The
// value of this variable will change according to the click of the button by
// the user. The Home component will render the DispalyMessage
// component to display the message and it will also render one of the
// components among Login and Logout based on the value stored
// in isLoggedIn. The DispalyMessage component will also return different
// messages based on the value of state isLoggedIn and ouput should be
// following
