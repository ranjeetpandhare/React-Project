import React from 'react'

function Logout(props) {
    return (
        <div>
           <button onClick={props.displayHandler}>Logout</button> 
        </div>
    )
}

export default Logout
